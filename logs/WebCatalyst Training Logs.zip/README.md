# W&B LaTeX Source

This directory was generated from the report named [WebCatalyst Training Logs](https://forge.coreweave.com/wandb/2546401325-nanyang-technological-university-singapore/agens_verl_qwen36/reports/Untitled-Report--VmlldzoxODE3ODUxOQ/edit?draftId=VmlldzoxODE3ODUxOQ==&firstReport&runsetFilter).

All charts are rendered as high resolution PNG's in the **charts** directory.  The tables in
this report were generated from the pinned columns in the open runsets.  The underlying data
is available in the **runsets** directory.

## Quickstart

You can upload this zip into a new project at [Overleaf](https://www.overleaf.com/).
Choose "Upload Project" from the "New Project" menu to edit online.

## Rendering Locally

You'll need a tex distribution, specifically the `pdflatex` command.  The following are good options:

1. [TinyTex](https://yihui.name/tinytex/) - `wget -qO- "https://yihui.name/gh/tinytex/tools/install-unx.sh" | sh`
2. [TexLive](https://tug.org/texlive/) - `apt-get install texlive`
3. [BasicTex](http://tug.org/cgi-bin/mactex-download/BasicTeX.pkg) *(Mac)* - `brew cask install basictex`
4. [MiKTeX](https://miktex.org/download) *(Windows)*

Once installed, run: `pdflatex report.tex` to generate a pdf.